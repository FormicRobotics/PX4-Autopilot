# hw definition file for processing by chibios_pins.py
# for TBS FCAPv1 H743

# MCU class and specific type
MCU STM32H7xx STM32H743xx

# board ID. See Tools/AP_Bootloader/board_types.txt
APJ_BOARD_ID AP_HW_TBS_LUCID_H7

# crystal frequency, setup to use external oscillator
OSCILLATOR_HZ 8000000

FLASH_SIZE_KB 2048

# bootloader starts at zero offset
FLASH_RESERVE_START_KB 0

# the location where the bootloader will put the firmware
# the H743 has 128k sectors
FLASH_BOOTLOADER_LOAD_KB 128

# order of UARTs (and USB). Allow bootloading on USB and telem1
SERIAL_ORDER OTG1 UART7

# UART7 (telem1)
PE7 UART7_RX UART7 NODMA
PE8 UART7_TX UART7 NODMA

# PA10 IO-debug-console
PA11 OTG_FS_DM OTG1
PA12 OTG_FS_DP OTG1

PA13 JTMS-SWDIO SWD
PA14 JTCK-SWCLK SWD

PE3 LED_BOOTLOADER OUTPUT LOW
define HAL_LED_ON 0

# Add CS pins to ensure they are high in bootloader
PC15 IMU1_CS CS
PB12 MAX7456_CS CS
PE11 IMU2_CS CS
PD4 EXT_CS1 CS
PE2 EXT_CS2 CS

# Ensure GPIOs are on during bootloader
# Vsw
PD10 VSW OUTPUT LOW
# CamSw
PD11 CAMSW OUTPUT LOW
# 9V_EN
PC13 VPWR OUTPUT LOW

# support flashing from SD card:
# enable DFU by default
ENABLE_DFU_BOOT 1

# FATFS support:
define CH_CFG_USE_MEMCORE 1
define CH_CFG_USE_HEAP 1
define CH_CFG_USE_SEMAPHORES 0
define CH_CFG_USE_MUTEXES 1
define CH_CFG_USE_DYNAMIC 1
define CH_CFG_USE_WAITEXIT 1
define CH_CFG_USE_REGISTRY 1

# microSD support
PC8 SDMMC1_D0 SDMMC1
PC9 SDMMC1_D1 SDMMC1
PC10 SDMMC1_D2 SDMMC1
PC11 SDMMC1_D3 SDMMC1
PC12 SDMMC1_CK SDMMC1
PD2 SDMMC1_CMD SDMMC1

define FATFS_HAL_DEVICE SDCD1
define HAL_OS_FATFS_IO 1
define AP_BOOTLOADER_FLASH_FROM_SD_ENABLED 1

