/****************************************************************************
 *
 *   Copyright (c) 2021 PX4 Development Team. All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 * 3. Neither the name PX4 nor the names of its contributors may be
 *    used to endorse or promote products derived from this software
 *    without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
 * BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS
 * OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
 * AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
 * ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 *
 ****************************************************************************/

/**
 * @file board_config.h
 *
 * Board internal definitions
 */

#pragma once

/****************************************************************************************************
 * Included Files
 ****************************************************************************************************/

#include <px4_platform_common/px4_config.h>
#include <nuttx/compiler.h>
#include <stdint.h>

#include <stm32_gpio.h>

/****************************************************************************************************
 * Definitions
 ****************************************************************************************************/

#define FLASH_BASED_PARAMS


/* LEDs - Active LOW (based on ArduPilot hwdef) */

#define GPIO_nLED_BLUE          /* PE3  */  (GPIO_OUTPUT|GPIO_PUSHPULL|GPIO_SPEED_50MHz|GPIO_OUTPUT_SET|GPIO_PORTE|GPIO_PIN3)
#define GPIO_nLED_GREEN         /* PE4  */  (GPIO_OUTPUT|GPIO_PUSHPULL|GPIO_SPEED_50MHz|GPIO_OUTPUT_SET|GPIO_PORTE|GPIO_PIN4)

#define BOARD_HAS_CONTROL_STATUS_LEDS   1
#define BOARD_ARMED_STATE_LED           1 // Green LED on PE4
#define BOARD_OVERLOAD_LED              0 // Blue LED on PE3

/*
 * ADC channels
 *
 * These are the channel numbers of the ADCs of the microcontroller that
 * can be used by the Px4 Firmware in the adc driver
 */

/* ADC defines to be used in sensors.cpp to read from a particular channel */
#define ADC1_CH(n)                  (n)
#define ADC3_CH(n)                  (n)

#define BOARD_NUMBER_BRICKS               2
#define BOARD_ADC_BRICK1_VALID            1
#define BOARD_ADC_BRICK2_VALID            1

/* Define GPIO pins used as ADC N.B. Channel numbers must match below  */
#define PX4_ADC_GPIO  \
	/* PC0  */  GPIO_ADC123_INP10, \
	/* PC1  */  GPIO_ADC123_INP11, \
	/* PA4  */  GPIO_ADC12_INP18, \
	/* PA7  */  GPIO_ADC12_INP7, \
	/* PC4  */  GPIO_ADC12_INP4, \
	/* PC5  */  GPIO_ADC12_INP8

/* Define Channel numbers must match above GPIO pin IN(n)*/
#define ADC_BATTERY1_VOLTAGE_CHANNEL     	/* PC0  */  ADC1_CH(10)
#define ADC_BATTERY1_CURRENT_CHANNEL     	/* PC1  */  ADC1_CH(11)
#define ADC_BATTERY2_VOLTAGE_CHANNEL     	/* PA4  */  ADC1_CH(18)
#define ADC_BATTERY2_CURRENT_CHANNEL     	/* PA7  */  ADC1_CH(7)
#define ADC_SCALED_V5_CHANNEL     	 	/* PC4  */  ADC1_CH(4)
#define ADC_SCALED_VDD_3V3_SENSORS_CHANNEL 	/* PC5  */  ADC1_CH(8)

#define ADC_CHANNELS \
	((1 << ADC_BATTERY1_VOLTAGE_CHANNEL)	| \
	(1 << ADC_BATTERY1_CURRENT_CHANNEL)	| \
	(1 << ADC_BATTERY2_VOLTAGE_CHANNEL)	| \
	(1 << ADC_BATTERY2_CURRENT_CHANNEL)	| \
	(1 << ADC_SCALED_V5_CHANNEL)		| \
	(1 << ADC_SCALED_VDD_3V3_SENSORS_CHANNEL))

// /* Define Battery 1 Voltage Divider and A per V */

#define BOARD_BATTERY1_V_DIV         (19.1f)     /* measured with the provided PM board */
#define BOARD_BATTERY1_A_PER_V       (0.0f)
#define BOARD_BATTERY2_V_DIV         (19.1f)     /* measured with the provided PM board */
#define BOARD_BATTERY2_A_PER_V       (0.0f)

/* CAN Silence
 *
 * Silent mode control \ ESC Mux select
 */

// #define GPIO_CAN1_SILENT_S0  /* PD3  */ (GPIO_OUTPUT|GPIO_PUSHPULL|GPIO_SPEED_2MHz|GPIO_OUTPUT_CLEAR|GPIO_PORTD|GPIO_PIN3)


/* PWM
 * TIM3: 2 channels (PWM 1-2: PB0, PB1)
 * TIM2: 2 channels (PWM 3-4: PA0, PA1)
 * TIM5: 2 channels (PWM 5-6: PA2, PA3)
 * TIM4: 4 channels (PWM 7-10: PD12-PD15)
 * TIM15: 2 channels (PWM 11-12: PE5, PE6)
 * TIM1: 1 channel (PWM 13: PA8 - WS2812 LED)
 * Total: 13 channels (12 motor outputs + 1 LED)
 * Note: PWM 13 (TIM1_CH1 on PA8) is used for LED/WS2812
 */
#define DIRECT_PWM_OUTPUT_CHANNELS   13
#define DIRECT_INPUT_TIMER_CHANNELS  6

#define BOARD_HAS_PWM  DIRECT_PWM_OUTPUT_CHANNELS

/*
 * Bidirectional DShot only supports a single timer (see _bidi_timer_index in
 * dshot.c). Timer index 3 is TIM4 (PWM 7-10: S7-S10), which has 4 channels -
 * more than any other timer on this board - so it's used as the bidir group.
 * (Channel 4 / S10 has no DMA capture line on STM32H7 and is skipped by the
 * driver's round-robin.)
 */
#define BOARD_BIDIRECTIONAL_DSHOT_TIMER_INDEX 3

/* Spare GPIO */

// #define GPIO_PG6                        /* PG6  */  (GPIO_INPUT|GPIO_PULLUP|GPIO_PORTG|GPIO_PIN6)
// #define GPIO_PD15                       /* PD15 */  (GPIO_INPUT|GPIO_FLOAT|GPIO_PORTD|GPIO_PIN15)
// #define GPIO_PG15                       /* PG15 */  (GPIO_INPUT|GPIO_PULLUP|GPIO_PORTG|GPIO_PIN15)


/* Buzzer on PA15, plain GPIO (matches ArduPilot hwdef: PA15 BUZZER OUTPUT) --- */
#define GPIO_TONE_ALARM_IDLE \
        (GPIO_OUTPUT|GPIO_PUSHPULL|GPIO_SPEED_2MHz|\
         GPIO_OUTPUT_CLEAR|GPIO_PORTA|GPIO_PIN15)

#define GPIO_TONE_ALARM_GPIO \
        (GPIO_OUTPUT|GPIO_PUSHPULL|GPIO_SPEED_2MHz|\
         GPIO_OUTPUT_SET|GPIO_PORTA|GPIO_PIN15)

/* High-resolution timer (HRT) --------------------------------------------- */
/* Changed to TIM8 to free TIM2 for PWM 3-4 (PA0, PA1) to match ArduPilot */
#define HRT_TIMER               8   /* use TIM8 for the HRT (was TIM2)     */
#define HRT_TIMER_CHANNEL       1   /* use capture/compare channel 1      */

/* No PPM input on this board (RC input is USART6, SERIAL6) */

/* No physical safety button/switch on this board (PC15 is IMU1_CS, PB1 is
 * a motor PWM output) — omit GPIO_BTN_SAFETY / GPIO_nSAFETY_SWITCH_LED_OUT,
 * matching other racing-FC boards without a PX4IO (e.g. kakuteh7mini). */

/* RC Serial port */
#define RC_SERIAL_PORT          "/dev/ttyS5"
#define BOARD_SUPPORTS_RC_SERIAL_PORT_OUTPUT

// #define GPIO_RSSI_IN            /* PC5  */ (GPIO_INPUT|GPIO_PULLUP|GPIO_PORTC|GPIO_PIN5)

/* Power Control GPIOs (must be LOW to enable power) */
#define GPIO_VSW                 /* PD10 */ (GPIO_OUTPUT|GPIO_PUSHPULL|GPIO_SPEED_2MHz|GPIO_OUTPUT_CLEAR|GPIO_PORTD|GPIO_PIN10)
/* Camera switch: HIGH selects camera input C1 (LOW = no video into the OSD chip) */
#define GPIO_CAMSW               /* PD11 */ (GPIO_OUTPUT|GPIO_PUSHPULL|GPIO_SPEED_2MHz|GPIO_OUTPUT_SET|GPIO_PORTD|GPIO_PIN11)
#define GPIO_VPWR                /* PC13 */ (GPIO_OUTPUT|GPIO_PUSHPULL|GPIO_SPEED_2MHz|GPIO_OUTPUT_CLEAR|GPIO_PORTC|GPIO_PIN13)

/* SD Card */
#define SDIO_SLOTNO             0  /* Only one slot */
#define SDIO_MINOR              0

/* This board provides a DMA pool and APIs */
#define BOARD_DMA_ALLOC_POOL_SIZE 5120

/* This board provides the board_on_reset interface */
#define BOARD_HAS_ON_RESET 1

#define PX4_GPIO_INIT_LIST { \
		PX4_ADC_GPIO, \
		GPIO_CAN1_TX, \
		GPIO_CAN1_RX, \
		GPIO_nLED_BLUE, \
		GPIO_nLED_GREEN, \
		GPIO_TONE_ALARM_IDLE, \
		GPIO_VSW, \
		GPIO_CAMSW, \
		GPIO_VPWR, \
	}

#define BOARD_ENABLE_CONSOLE_BUFFER

#define BOARD_NUM_IO_TIMERS 6

__BEGIN_DECLS

/****************************************************************************************************
 * Public Types
 ****************************************************************************************************/

/****************************************************************************************************
 * Public data
 ****************************************************************************************************/

#ifndef __ASSEMBLY__

/****************************************************************************************************
 * Public Functions
 ****************************************************************************************************/

/****************************************************************************
 * Name: stm32_sdio_initialize
 *
 * Description:
 *   Initialize SDIO-based MMC/SD card support
 *
 ****************************************************************************/

int stm32_sdio_initialize(void);

/****************************************************************************************************
 * Name: stm32_spiinitialize
 *
 * Description:
 *   Called to configure SPI chip select GPIO pins for the board.
 *
 ****************************************************************************************************/

extern void stm32_spiinitialize(void);

extern void stm32_usbinitialize(void);

extern void board_peripheral_reset(int ms);

#include <px4_platform_common/board_common.h>

#endif /* __ASSEMBLY__ */

__END_DECLS
